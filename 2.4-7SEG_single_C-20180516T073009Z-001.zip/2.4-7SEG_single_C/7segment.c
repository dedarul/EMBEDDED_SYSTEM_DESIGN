#include <mega32.h>
#include <delay.h>
#define output_port PORTB
#define data_direction DDRB
int digit_cathode[10]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
int i=0;


void main(void)

{
   data_direction=0xFF;

   while (1)
      {
      for(i=0;i<10;i++)
        {
            output_port=digit_cathode[i];
            delay_ms(250);   
        }
      }
}

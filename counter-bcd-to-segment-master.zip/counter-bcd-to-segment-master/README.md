# counter-bcd-to-segment
from back in the university, a digital design laboratory project, counting to segment

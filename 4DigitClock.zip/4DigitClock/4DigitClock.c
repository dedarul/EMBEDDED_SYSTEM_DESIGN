/*******************************************************
This program was created by the
CodeWizardAVR V3.12 Advanced
Automatic Program Generator
� Copyright 1998-2014 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : 4DigitClock
Version : 1.0.1
Date    : 10/17/2020
Author  : Md. Dedarul Hasan
Company : IICT-BUET
Comments: 
ESD TERM PROJECT


Chip type               : ATmega32
Program type            : Application
AVR Core Clock frequency: 16.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*******************************************************/

#include <mega32.h>
#include <delay.h>

int second=0;
int minute=0;
int second0=0;
int second1=0;
int minute0=0;
int minute1=0;
int stop=1;

int digit_cathod[10]={0X3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
int digit_cathod_decimal[10]={0XBF,0x86,0xDB,0xCF,0xE6,0xED,0xFD,0x87,0xFF,0xEF};

void display_digits(void)
{
      second1=second/10;
      second0=second%10;
      minute1=minute/10;
      minute0=minute%10;
}

// External Interrupt 0 service routine
interrupt [EXT_INT0] void ext_int0_isr(void)
{
    stop=0;
}

// External Interrupt 1 service routine
interrupt [EXT_INT1] void ext_int1_isr(void)
{
    second=0;
    minute=0;
    display_digits();
}

// External Interrupt 2 service routine
interrupt [EXT_INT2] void ext_int2_isr(void)
{
    stop=1;
}

// Timer2 output compare interrupt service routine
interrupt [TIM2_COMP] void timer2_comp_isr(void)
{
  TCNT2=0;
  if (stop==0)   
  {
    second++;
    if (second>=59)
      {
          second=0;
          minute++;
          if (minute>=59)
             minute=0;
      } 
      display_digits();
  }
}


void main(void)
{
// Timer/Counter 2 initialization
// Clock source: TOSC1 pin
// Clock value: PCK2/1024
// Mode: Normal top=0xFF
// OC2 output: Disconnected
ASSR=1<<AS2;
TCCR2=(0<<PWM2) | (0<<COM21) | (0<<COM20) | (0<<CTC2) | (1<<CS22) | (1<<CS21) | (1<<CS20);
TCNT2=0x00;
OCR2=0x20;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=(1<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (0<<OCIE0) | (0<<TOIE0);

// External Interrupt(s) initialization
// INT0: On
// INT0 Mode: Falling Edge
// INT1: On
// INT1 Mode: Falling Edge
// INT2: On
// INT2 Mode: Falling Edge
GICR|=(1<<INT1) | (1<<INT0) | (1<<INT2);
MCUCR=(1<<ISC11) | (0<<ISC10) | (1<<ISC01) | (0<<ISC00);
MCUCSR=(0<<ISC2);
GIFR=(1<<INTF1) | (1<<INTF0) | (1<<INTF2);

// Global enable interrupts
#asm("sei")

DDRA=0xFF;
DDRD=0xF0;

while (1)
      {
      
      PORTD=0x7F;
      PORTA=digit_cathod[second0];     
      delay_ms(1);
      //if(PIND.4==0){
      PORTD=0xBF;                  
      PORTA=digit_cathod[second1];
      delay_ms(1);
      PORTD=0xDF;
      PORTA=digit_cathod_decimal[minute0];
      delay_ms(1);
      PORTD=0xEF;
      PORTA=digit_cathod[minute1];
      delay_ms(1);
      }
}
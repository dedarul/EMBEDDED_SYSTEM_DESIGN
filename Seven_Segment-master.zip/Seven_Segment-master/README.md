# Seven_Segment
counter up to 100 using two seven segments on a single BCD_TO_7SEGMENT decoder

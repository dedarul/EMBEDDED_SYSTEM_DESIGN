/*******************************************************
This program was created by the
CodeWizardAVR V3.12 Advanced
Automatic Program Generator
� Copyright 1998-2014 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com
Project : DigitalClock
Version : 1.0.1
Date    : 9/7/2020
Author  : Md.Dedarul Hasan
Company : IICT-BUET
Comments: 
Embedded System Design Assignment
Chip type               : ATmega32
Program type            : Application
AVR Core Clock frequency: 16.000000 MHz
Memory model            : Small
External RAM size       : 0
Data Stack size         : 512
*******************************************************/
#include <mega32.h>
#include <delay.h>
// Declare your global variables here
// External Interrupt 0 service routine

#define sev_segment_ddr DDRB
#define sev_segment PORTB

int second=0;
int minute=0;
int hour=0;
int second0=0;
int second1=0;
int minute0=0;
int minute1=0;
int hour0=0;
int hour1=0;
int count=0;

/*int digit_cathod[10]={0X3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
int digit_cathod_decimal[10]={0XBF,0x86,0xDB,0xCF,0xE6,0xED,0xFD,0x87,0xFF,0xEF};*/

unsigned char time[9]= {0x11,0x22,0x43,0x84,0x05,0x06,0x07,0x08,0x09};
unsigned char i=0;
void display_digits(void)
{
      //second1=second/10;
      //second0=second%10;
      minute1=minute/10;
      minute0=minute%10;
      hour1=hour/10;
      hour0=hour%10;
} 
// Timer 0 overflow interrupt service routine
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
// Place your code here
count++;
    if(count==60){ 
        minute++;
        if (minute>=59)
          {
              minute=0;
              hour++;
              if (hour>=59)
                 hour=0;
          }
    } 
      display_digits();
      

}

void main(void)
{
// Declare your local variables here
    sev_segment_ddr=0xFF;
	//DDRA=0xFF;
	//PORTA=0x00;
	sev_segment=0x00;  

// Global enable interrupts
#asm("sei")
//DDRB=0xFF;
//DDRA=0xF0;

while (1)
      {
      // Place your code here
      //PORTB=0b00010001;
        sev_segment=time [i];
        delay_ms(1);
        //PORTB=0b00100010;
        sev_segment=time [i+1];
        delay_ms(1);
        //PORTB=0b00000100;
        sev_segment=time [i+2];
        delay_ms(1);
        //PORTB=0b00001000;
        sev_segment=time [i+3];
        delay_ms(1); 
        
        
          /*PORTA=0x7F;
          PORTB=digit_cathod[second0];     
          delay_ms(1);
          PORTA=0xBF;                  
          PORTB=digit_cathod[second1];
          delay_ms(1);
          PORTA=0xDF;
          PORTB=digit_cathod_decimal[minute0];
          delay_ms(1);
          PORTA=0xEF;
          PORTB=digit_cathod[minute1];
          delay_ms(1); */
        
      }
}

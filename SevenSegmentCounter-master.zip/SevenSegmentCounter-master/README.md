<p align="center">
  <img width="250" height="250" src="http://uupload.ir/files/n6gj_proteuslogo.png">
</p>





#  7-Segment Counter

####   BCD To 7-Segment Counter In Proteus Using 555 Pulse Generator.

---

#### 

<p align="center">
  <img src="http://uupload.ir/files/lop0_screen_shot_1398-02-14_at_1.31.26_pm.png">
</p>

